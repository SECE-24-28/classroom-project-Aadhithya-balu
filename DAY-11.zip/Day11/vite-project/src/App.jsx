import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Home from './Components/Home'
import Dashboard from './Components/Dashboard'
import ProtectedRoutes from './Components/ProtectedRoutes'
import PublicRoutes from './Components/PublicRoutes'

function App() {
  const router = createBrowserRouter([
    {
      path: '/',
      element: (
        <PublicRoutes>
          <Home />
        </PublicRoutes>
      )
    },
    {
      path: '/dash',
      element: (
        <ProtectedRoutes>
          <Dashboard />
        </ProtectedRoutes>
      )
    }
  ])

  return <RouterProvider router={router} />
}

export default App
