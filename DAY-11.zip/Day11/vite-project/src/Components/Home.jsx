import { useNavigate } from 'react-router-dom'

const Home = () => {
  const navigate = useNavigate()

  const handleLogin = () => {
    localStorage.setItem('isAuth', 'true')
    navigate('/dash')
  }

  return (
    <div className="flex flex-col items-center justify-center h-screen gap-5">
      <h1 className="text-3xl font-bold">Home</h1>
      <button className="loginBtn" onClick={handleLogin}>
        Login
      </button>
    </div>
  )
}

export default Home
