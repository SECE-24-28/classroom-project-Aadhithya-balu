
import { Navigate } from 'react-router-dom'

const PublicRoutes = ({ children }) => {
  const isAuth = localStorage.getItem('isAuth') === 'true'

  if (isAuth) {
    return <Navigate to="/dash" replace />
  }

  return children
}

export default PublicRoutes
