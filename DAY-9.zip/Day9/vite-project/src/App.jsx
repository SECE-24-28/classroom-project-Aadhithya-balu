import './App.css'
import { useState , useRef } from 'react';

function App() {

  //useRef is a Hook provided by React that helps us pass a reference
  const nameRef=useRef()
  const emailRef=useRef()

  const[formData,setFormData]=useState({
    uname:"",
    email:"",
  })   

  const handleChange=(e)=>{
    setFormData({
      ...formData,
      [e.target.name]:e.target.value,
    }) // controlled component because we can 
  }

  const handleSubmit=(e)=>{
   if(!formData.email.includes('@')){
    alert("Your email is not valid");
    return;
   }

   if(formData.uname.length<3){
    alert("Enter appropriate Name");
    return;
   }

    e.preventDefault();

    console.log(formData);
    nameRef.current.value = ""; //uncontrolled component because all of its data is kept internally.
    emailRef.current.value = "";

  }

  return (
    <>
      <div className="text-center text-4xl bg-blue-500 text-white">This is a app</div>
 
      <form onSubmit={handleSubmit}>
        <input ref={nameRef} className="inputs" type="text" name="uname" placeholder="Enter Name" value={formData.uname} onChange={handleChange}/>
        <input ref={emailRef} className="inputs" type="text" name="email" placeholder="Enter Email" value={formData.email} onChange={handleChange}/>  
        <input className="inpBtn" type="submit" value="Submit"/>
      </form>
    </>
  )
}

export default App