import { useParams } from "react-router-dom";
import "../Styles/Post.css";
import { useState, useEffect } from "react";

const Post = () => {
  const { id } = useParams();
  const [post, setPost] = useState(
    {
        "title":"Nothing",
        "body":"Nothing",
    }
  );

  useEffect(() => {
    fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then((response) => response.json())
      .then((data) => setPost(data));
  }, [id]);

  return (
    <>
      <div className="card mx-auto mt-10">
        <h2 className="text-2xl font-bold mb-4">Post: {post?.title}</h2>
        <p className="text-lg">
          This is the post with ID:{" "}
          <span className="font-mono text-yellow-300">{post?.id}</span>
        </p>
        <p className="text-lg forced-color-adjust-none">
          {post?.body}
        </p>
      </div>
    </>
  );
};

export default Post;