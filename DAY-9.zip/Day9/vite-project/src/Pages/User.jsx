import React from "react";
import { useParams } from "react-router-dom";

const User=()=>
{
    const user=useParams();
    return (<div className="text-center p-6 from-neutral-200">
           User Component<span className="text-5xl text-red-400">${user.id}</span>
        </div>);
}
export default User;

