

const Detail=()=>{

   {/*Conditional Rendering*
     const logger = true;  */}

    return(
        <nav>
            <div className="text-center text-4xl bg-blue-500 text-white">
                THis is the process how it works
            </div>


            {/*Conditional Rendering*
            <div>
                {logger && <div className="text-6xl text-blue=500"> You are logged in </div>}
                {logger ? <div className="text-6xl text-blue=500"> You can access the dashboard</div> :<div
                    className="text-6xl text-blue=500">You cannot access the dashboard
                    </div>
                }
            </div> */}

        </nav>
    )
}

export default Detail;