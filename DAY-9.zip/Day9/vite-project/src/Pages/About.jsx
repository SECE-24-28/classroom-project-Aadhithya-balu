import React from 'react'

const About = () => {
  return (
    <div className="text-center text-4xl bg-blue-500 text-white">
        THis is a about page
    </div>
  )
}

export default About