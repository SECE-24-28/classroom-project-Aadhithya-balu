import {Link} from "react-router-dom"
import '../Styles/Navbar.css'
const Navbar=()=>{
    return(
         <nav className="navbar">
            <div className="navStyle">
                <Link className="items" to={'/'}>Home</Link>
                <Link className="items" to={'/about'}>About</Link>
                <Link className="items" to={'/detail'}>Detail</Link>
                <Link className="items" to={'user/id'}>User</Link>
                <Link className="items" to={'/Post/id'}>Post</Link>


            </div>
         </nav>
    )
}

export default Navbar;