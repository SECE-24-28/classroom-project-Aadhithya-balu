import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import Layout from './Layouts/Layout.jsx'
import About from './Pages/About'
import Detail from './Pages/Detail'
import User from './Pages/User'
import Post from './Pages/Post'
import {createBrowserRouter,RouterProvider} from 'react-router-dom'

const router=createBrowserRouter([
  {
    path:'/',
    element:<Layout/>,
    children:[
      {
        index:true,
        element:<App/>
      },
      {
        path:'about',   // ✔ no slash
        element:<About/>
      },
      {
        path:'detail',
        element:<Detail/>
      },
      {
        path:'user/:id',
        element:<User/>
      },
      {
        path:'post/:id',
        element:<Post/>
      }
    ]
  }
])





createRoot(document.getElementById('root')).render(
  <StrictMode>
    {/* <App /> */}
    <RouterProvider router={router} />
  </StrictMode>,
)
