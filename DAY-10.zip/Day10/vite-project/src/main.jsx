import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import {createBrowserRouter,RouterProvider} from 'react-router-dom'
import { Link } from "react-router-dom"
import Dashboard from './components/Dashboard'
import Profile from './components/Profile'
import Settings from './components/Settings'
import Forms from './components/Forms'


const router = createBrowserRouter([
    {path: '/',element:<App/>},
    {
      path:"/dashboard", 
      element:<Dashboard/>,
      children:[
        {path: 'profile',element:<Profile/>}  ,
        {path: 'settings',element:<Settings/>},
      ]
    },
    {path: '/forms',element:<Forms/>}
])

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router}/>
  </StrictMode>,
)
