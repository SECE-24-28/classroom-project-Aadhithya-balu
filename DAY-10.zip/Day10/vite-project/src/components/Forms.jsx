import { useForm } from "react-hook-form"
import '../Styles/Forms.css'

export default function App() {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    uname:'User',
    email:'abc@example.com'   //default values

  })


  const onSubmit = (data) => console.log(data)


  console.log(watch("example")) // watch input value by passing the name of it


  return (
    /* "handleSubmit" will validate your inputs before invoking "onSubmit" */
    <form className="myForm" onSubmit={handleSubmit(onSubmit)}>
       <input className="inputs" type="text" {...register('uname',{required:true,minLength:{value:3,message:"Minimum 3 characters"},maxLength:{value:10,message:"Maximum 10 characters"}})} placeholder="Enter Name"/>
       {/*React hook form errors*/}
       {/* {errors.uname && <div className="errorStyle">*This field is required</div>} */}
       {errors.uname && (<div className="errorStyle">{errors.uname.message}
  </div>
)}


      <input className="inputs" type="email" {...register('email',{required:true})} placeholder="Enter E-Mail"/>
      {errors.email && <div className="errorStyle">*This field is required</div>}

      <input className="subBtn" type="submit"/>
      
    </form>
  )
}  