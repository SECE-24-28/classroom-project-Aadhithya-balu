import React from 'react'

const Home = () => {
  return (
    <div>
      This is a Home page
    </div>
  )
}

export default Home