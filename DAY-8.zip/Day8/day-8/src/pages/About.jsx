import React from 'react'

const About = () => {
  return (
    <div>
      This is an About page
    </div>
  )
}

export default About