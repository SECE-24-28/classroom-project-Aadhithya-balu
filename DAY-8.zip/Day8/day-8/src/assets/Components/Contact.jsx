import React from 'react'
import '../Styles/Contact.css'
const Contact = () => {
  return (
    <div className='contactStyle'>
        This is a Contact
      
    </div>
  )
}

export default Contact
