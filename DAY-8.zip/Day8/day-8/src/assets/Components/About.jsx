import React from 'react'
import '../Styles/About.css'
const About = () => {
  return (
    <div className='aboutStyle'>
      This is a about  page
    </div>
  )
}

export default About
