import React from 'react'
import { Link } from 'react-router-dom'
import '../Styles/NavBar.css'

const NavBar = () => {
  return (
    <nav className='flex justify-center items-center gap-5 bg-blue-500 text-white font-bold p-4'>
      <Link to={'/'}>Home</Link>
      <Link to={'/contact'}>Contact Us</Link>
      <Link to={'/about'}>About Us</Link>
     {/*<ul className='navStyle'>
        <li className='items'>Home</li>
        <li className='items'>Contact Us</li>
        <li className='items'>About Us</li>

            </ul> */}
    </nav>
  )
}

export default NavBar
