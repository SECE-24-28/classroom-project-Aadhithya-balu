import './App.css'
import { useState, useEffect } from 'react'
import NavBar from './assets/Components/NavBar.jsx';
import {Routes,Route} from 'react-router-dom';
import Home from './pages/Home.jsx';
import About from './pages/About.jsx';
import Contact from "./pages/Contact.jsx";
import Layout from './Layouts/Layout.jsx';


function App() {
  //use effect is a hook that we use in order to create a some side effects in our app.Side effects include DOM mutiliation,
  // fetching data from as erver using API'S ,managing subscription,timers,taking logs,etc.






  // const [count, setCount] = useState(0)





  // useEffect(() => {
  //   alert("This is the first thing after rendering");
  // }, [])






  // useEffect(() => {
  //   /*alert("This is the increment thing after rendering");*/
  //   /*console.log("useful effect in USe...");*/
  //   console.log("count is chnaged",count);



  //   let timer;
  //   if(count<0){
  //     timer=setTimeout(()=>{
  //         setCount(0);
  //     },2000)
  //   }
  //   return()=>{
  // if(timer){
  //   clearTimeout(timer);
  //   //this is a cleanup function
  // }
 //}
  //}, [count]) // [] it is will run only once on the first rendering
  //[states] it will render on the first rendering and whenver states and/or variables updated/changed
 
 
 
 
  /*useEffect(() => {
    alert("This is the increment thing after rendering");
  }, [uname,email])  [state1,state2,state3] it will run on the first render and whenver any of the 3 staes/variables changes*/
  
  
  

  const[posts,setPosts]=useState([]);
  useEffect(()=>{
    async function fetchPosts(){
      //fetch data from jsonplacehilder using fetch API
    const rawData=await fetch('https://jsonplaceholder.typicode.com/posts');
    //converting the raw data into a json format
    const data=await rawData.json();
    //saving the converted data into a state called posts
    setPosts(data);

}//calling the fetchPosts function
fetchPosts();
},[])
  






  return (
    <>
      {/* <div className='text-center text-4xl bg-green-500 text-white'>
        {count}
      </div>

      <button
        className='countBtn bg-blue-500 text-white p-3 rounded mt-5' onClick={() => setCount(count + 1)}>
      
        Increment
      </button>


      <button
        className='countBtn1 bg-blue-500 text-white p-3 rounded mt-5' onClick={() => setCount(count-1)}>
        Decrement
      </button> */}

      {/* <div className="container bg-red-500"> */}
      {/* <div className="cardContainer">
      {posts.map((post)=>(
          <div key={post.id} className='card'>
            <h2 className='cardTitle'>{post.title}</h2>
            <h2  className='cardBody'>{post.body}</h2>
          </div>
        
      ))}
    </div> */}
    <NavBar/>
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="contact" element={<Contact />} />
      </Route>
    </Routes>
    </>
  )
}
export default App

