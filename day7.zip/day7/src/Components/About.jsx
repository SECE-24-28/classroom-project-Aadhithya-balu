function About() {
  return (
    <div className="about-container">
      <h2>About Us</h2>
      <p>
        Welcome to our Vite + React project! This is a modern web application
        built with cutting-edge technologies for optimal performance and developer experience.
      </p>
      <h3>Our Mission</h3>
      <p>
        We strive to create efficient, scalable, and user-friendly applications
        that solve real-world problems.
      </p>
      <h3>Technologies Used</h3>
      <ul>
        <li>React - A JavaScript library for building user interfaces</li>
        <li>Vite - A next-generation frontend build tool</li>
        <li>JavaScript - The programming language of the web</li>
      </ul>
    </div>
  )
}

export default About