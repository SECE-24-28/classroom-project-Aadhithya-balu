const Navbar = () => {
    return (
        <nav>
             <ul className="flex justify-center items-center gap-5 p5 bg-blue-500 text-white font-extrabold text-2x1">
                <li className="hover:bg-blue-700 p-5 transition">Home</li>
                <li className="hover:bg-blue-700 p-5 transition">About</li>
                <li className="hover:bg-blue-700 p-5 transition">Contact</li>
            </ul>
        </nav>
    )
}

export default Navbar;